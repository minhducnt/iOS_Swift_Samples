IOS 14 APP WITH SWIFTUI 2
Dear App Developer,

1. COMPLETED FOLDER:

This folder contains the finished project. You can use it as a reference guide in your learning.

2. RESOURCES FOLDER:

This folder contains all of the necessary materials of the project. 

3. STUDENTS FOLDER:

This folder is the destination of your own Xcode project.

4. WORKBOOK:

The PDF file is the workbook for this project.


Happy Coding,
Robert Petras


SWIFTUI MASTERCLASS

Website: https://swiftuimasterclass.com
Twitter: https://twitter.com/robertpetras

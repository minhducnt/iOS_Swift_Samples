//
//  ViewController.swift
//  I am Rich
//
//  Created by TMA on 11/2/25.
//

import UIKit

class ViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
}

//
//  DiceViewApp.swift
//  DiceView
//
//  Created by TMA on 13/2/25.
//

import SwiftUI

@main
struct DiceViewApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

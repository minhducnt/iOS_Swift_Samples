//
//  ContentView.swift
//  OnboardingFlow
//
//  Created by TMA on 11/2/25.
//

import SwiftUI

let gradientColors: [Color] = [
    .gradientTop,
    .gradientBottom,
]

struct ContentView: View {
    var body: some View {
        TabView {
            WelcomePage()
            FeaturePage()
        }
        .tabViewStyle(.page)
        .background(Gradient(colors: gradientColors))
        .foregroundColor(.white)
    }
}

#Preview {
    ContentView()
}

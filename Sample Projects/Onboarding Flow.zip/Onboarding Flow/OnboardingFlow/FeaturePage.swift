//
//  FeaturePage.swift
//  OnboardingFlow
//
//  Created by TMA on 11/2/25.
//

import SwiftUI

struct FeaturePage: View {
    var body: some View {
        VStack(spacing: 30) {
            Text("Features")
                .font(.title)
                .fontWeight(.semibold)
                .padding(.bottom)

            ScrollView {
                VStack {
                    FeatureCard(iconName: "person.2.crop.square.stack.fill",
                                description: "A multiline description about a feature paired with the image on the left.")

                    FeatureCard(iconName: "quote.bubble.fill", description: "Short summary")
                }
            }
        }
        .padding()
    }
}

struct FeaturePage_Previews: PreviewProvider {
    static var previews: some View {
        FeaturePage()
            .frame(maxHeight: .infinity)
            .background(Gradient(colors: gradientColors))
            .foregroundStyle(.white)
    }
}

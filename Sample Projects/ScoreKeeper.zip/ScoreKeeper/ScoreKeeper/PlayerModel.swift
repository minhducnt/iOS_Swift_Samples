//
//  PlayerModel.swift
//  ScoreKeeper
//
//  Created by TMA on 13/2/25.
//

import UIKit

struct PlayerModel: Identifiable {
    let id = UUID()

    var name: String
    var score: Int
}

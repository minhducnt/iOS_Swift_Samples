//
//  WeatheForecastApp.swift
//  WeatheForecast
//
//  Created by TMA on 11/2/25.
//

import SwiftUI

@main
struct WeatheForecastApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

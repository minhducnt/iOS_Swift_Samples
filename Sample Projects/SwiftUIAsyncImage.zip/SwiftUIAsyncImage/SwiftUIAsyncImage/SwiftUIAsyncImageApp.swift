//
//  SwiftUIAsyncImageApp.swift
//  SwiftUIAsyncImage
//
//  Created by TMA on 17/2/25.
//

import SwiftUI

@main
struct SwiftUIAsyncImageApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

//
//  ContentView.swift
//  SwiftUIAsyncImage
//
//  Created by TMA on 17/2/25.
//

import SwiftUI

extension Image {
    func imageModifiers() -> some View {
        resizable()
            .scaledToFit()
    }

    func iconModifiers() -> some View {
        imageModifiers()
            .frame(maxWidth: 128)
            .foregroundColor(.gray)
            .opacity(0.5)
    }
}

struct ContentView: View {
    private let imageURL: String = "https://credo.academy/credo-academy@3x.png"

    var body: some View {
        // MARK: - 1. BASIC

        // AsyncImage(url: URL(string: imageURL))

        // MARK: - 2. SCALE

        // AsyncImage(url: URL(string: imageURL), scale: 2.5)

        // MARK: - 3. PLACEHOLDER

        /*
         AsyncImage(url: URL(string: imageURL)) { image in
             image.imageModifiers()
         } placeholder: {
             Image(systemName: "photo.circle.fill").iconModifiers()
         }
         .padding(40)
          */

        // MARK: - 4. PHASE

        /*
         AsyncImage(url: URL(string: imageURL)) { phase in
             if let image = phase.image {
                 image.imageModifiers()
             } else if phase.error == nil {
                 Image(systemName: "ant.circle.fill").iconModifiers()
             } else {
                 Image(systemName: "photo.circle.fill").iconModifiers()
             }
         }
         .padding(40)
          */

        // MARK: - 5. ANIMATION

        AsyncImage(url: URL(string: imageURL), transaction: Transaction(animation: .spring(response: 0.5, dampingFraction: 0.6, blendDuration: 0.25))) { phase in
            switch phase {
            case let .success(image):
                image.imageModifiers()
                    // .transition(.move(edge: .bottom))
                    // .transition(.slide)
                    .transition(.scale(scale: 0.5))
            case .failure:
                Image(systemName: "ant.circle.fill").iconModifiers()
            case .empty:
                Image(systemName: "photo.circle.fill").iconModifiers()
            @unknown default:
                ProgressView()
            }
        }
        .padding(40)
    }
}

#Preview {
    ContentView()
}

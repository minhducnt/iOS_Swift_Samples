//
//  Pick_a_PalApp.swift
//  Pick-a-Pal
//
//  Created by TMA on 13/2/25.
//

import SwiftUI

@main
struct Pick_a_PalApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

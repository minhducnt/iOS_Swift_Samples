//
//  ContentView.swift
//  Pick-a-Pal
//
//  Created by TMA on 13/2/25.
//

import SwiftUI

struct ContentView: View {
    @State private var names: [String] = []
    @State private var inputName = ""
    @State private var pickedName = ""
    @State private var shouldRemovePickedName = false

    var body: some View {
        VStack {
            VStack(spacing: 8) {
                Image(systemName: "person.3.sequence.fill")
                    .foregroundStyle(.blue)
                    .symbolRenderingMode(.hierarchical)
                Text("Pick-a-Pal")
            }
            .font(.title)
            .bold()

            Text(pickedName.isEmpty ? " " : pickedName)

            List {
                ForEach(names, id: \.description) {
                    name in Text(name)
                }
            }

            TextField("Add Name", text: $inputName)
                .autocorrectionDisabled()
                .onSubmit {
                    if !inputName.isEmpty {
                        names.append(inputName)
                        inputName = ""
                    }
                }
                .padding()

            Divider()

            Toggle("Remove when picked", isOn: $shouldRemovePickedName).padding()

            Button {
                if let randomName = names.randomElement() {
                    pickedName = randomName

                    if shouldRemovePickedName {
                        names.removeAll { name in
                            name == randomName
                        }
                    }
                } else {
                    pickedName = ""
                }
            }
            label: {
                Text("Pick Random Name")
                    .padding(.vertical, 8)
                    .padding(.horizontal, 16)
            }
            .buttonStyle(.borderedProminent)
            .font(.system(size: 20))
        }
        .padding()
    }
}

#Preview {
    ContentView()
}

//
//  AboutMeApp.swift
//  AboutMe
//
//  Created by TMA on 11/2/25.
//

import SwiftUI

@main
struct AboutMeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

//
//  main.swift
//  Protocols And Delegates
//
//  Created by TMA on 14/2/25.
//

protocol AdvancedLifeSupport {
    func performCPR()
}

class EmergencyMedicalServices {
    var delegate: AdvancedLifeSupport?

    func assessSituation() {
        print("Can you tell me what happened?")
    }

    func medicalEmergency() {
        delegate?.performCPR()
    }
}

struct Paramedic: AdvancedLifeSupport {
    init(handler: EmergencyMedicalServices) {
        handler.delegate = self
    }

    func performCPR() {
        print("The paramedic did CPR")
    }
}

class Doctor: AdvancedLifeSupport {
    init(handler: EmergencyMedicalServices) {
        handler.delegate = self
    }

    func performCPR() {
        print("The doctor did CPR")
    }

    func useStethescope() {
        print("Listening for heart sounds")
    }
}

class Surgeon: Doctor {
    override func performCPR() {
        super.performCPR()
        print("Sings staying alive by the BeeGees")
    }

    func useElectricdrill() {
        print("Whirrr.....")
    }
}

let Jackson = EmergencyMedicalServices()
let Pete = Paramedic(handler: Jackson)
let Angela = Surgeon(handler: Jackson)

Jackson.assessSituation()
Jackson.medicalEmergency()

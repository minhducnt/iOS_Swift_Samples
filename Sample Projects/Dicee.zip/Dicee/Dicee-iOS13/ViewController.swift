//
//  ViewController.swift
//  Dicee-iOS13
//
//  Created by Angela Yu on 11/06/2019.
//  Copyright © 2019 London App Brewery. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    // Array of dice images
    var diceImages = [
        "DiceOne",
        "DiceTwo",
        "DiceThree",
        "DiceFour",
        "DiceFive",
        "DiceSix",
    ]

    var leftDiceNumb = 1

    func randomDice() -> UIImage {
        // Pick a random image name from the array
        let randomIndex = Int.random(in: 0 ..< diceImages.count)
        let randomImageName = diceImages[randomIndex]

        // Load the image from the asset catalog
        return UIImage(named: randomImageName)!
    }

    func randomDice2() -> UIImage {
        return UIImage(named: diceImages.randomElement()!)!
    }

    @IBOutlet var diceImageOne: UIImageView!

    @IBOutlet var diceImageTwo: UIImageView!

    @IBAction func onDiceBtnTapped(_: UIButton) {
        diceImageOne.image = randomDice2()
        diceImageTwo.image = randomDice2()
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
}

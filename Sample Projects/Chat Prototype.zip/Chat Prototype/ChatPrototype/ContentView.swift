//
//  ContentView.swift
//  ChatPrototype
//
//  Created by TMA on 11/2/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Text("Hello, world")
                .padding()
                .background(Color.yellow, in: RoundedRectangle(cornerRadius: 20))

            Text("I am Rich!")
                .padding(24)
                .background(Color.teal, in: RoundedRectangle(cornerRadius: 40))
        }
        .padding()
    }
}

#Preview {
    ContentView()
}

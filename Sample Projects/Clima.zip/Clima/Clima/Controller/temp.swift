//
//  temp.swift
//  Clima
//
//  Created by TMA on 14/2/25.
//  Copyright © 2025 App Brewery. All rights reserved.
//

//
//  ViewController.swift
//  Clima
//
//  Created by Angela Yu on 01/09/2019.
//  Copyright © 2019 App Brewery. All rights reserved.
//

import CoreLocation
import UIKit

class WeatherViewController: UIViewController {
    @IBOutlet var conditionImageView: UIImageView!
    @IBOutlet var temperatureLabel: UILabel!
    @IBOutlet var cityLabel: UILabel!
    @IBOutlet var searchTextField: UITextField!

    let weatherManager = WeatherManager()
    let locationManager = CLLocationManager()

    override func viewDidLoad() {
        super.viewDidLoad()

        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.requestLocation()

        weatherManager.delegate = self
        searchTextField.delegate = self

        // Non-Async/Await
        //         initWeatherManager1()

        // Async/Await
        //         initWeatherManager2()

        // Async/Await with Completion Handler
        //         initWeatherManager3()

        // Group Tasks
        //         initWeatherManager4()
    }

    // Không có async/await
    func initWeatherManager1() {
        weatherManager.fetchAPI1 { (result: Result<WeatherData, Error>) in
            DispatchQueue.main.async {
                switch result {
                case let .success(weatherData):
                    self.temperatureLabel.text = String(
                        weatherData.main?.temp ?? 0.0)
                    self.cityLabel.text = weatherData.name ?? "Unknown"
                case .failure:
                    let alert = UIAlertController(
                        title: "Error",
                        message:
                        "Failed to fetch weather data. Please try again later.",
                        preferredStyle: .alert
                    )
                    alert.addAction(
                        UIAlertAction(
                            title: "OK", style: .default, handler: nil
                        ))
                    self.present(alert, animated: true, completion: nil)
                }
            }
        }
    }

    // Cách 1: Async/Await
    func initWeatherManager2() {
        Task.init {
            do {
                let result: WeatherData = try await weatherManager.fetchAPI2()
                self.temperatureLabel.text = String(result.main?.temp ?? 0.0)
                self.cityLabel.text = result.name ?? "Unknown"
            } catch {
                print(error.localizedDescription)
            }
        }
    }

    // Cách 2: Async with Completion Handler
    func initWeatherManager3() {
        Task.init {
            do {
                let result = try await weatherManager.loadAPI3()
                self.temperatureLabel.text = String(result.main?.temp ?? 0.0)
                self.cityLabel.text = result.name ?? "Unknown"
            } catch {
                print(error.localizedDescription)
            }
        }
    }

    // Cách 3: Fetch group APIs
    func initWeatherManager4() {
        let urls = [
            URL(string: weatherManager.weatherURL)!,
        ]

        Task.init {
            do {
                let result: [WeatherData] = try await weatherManager.loadAPI4(
                    urls: urls)
                self.temperatureLabel.text = String(
                    result.first?.main?.temp ?? 0.0)
                self.cityLabel.text = result.first?.name ?? "Unknown"
            } catch {
                print(error.localizedDescription)
            }
        }
    }
}

// MARK: - UITextFieldDelegate

extension WeatherViewController: UITextFieldDelegate {
    @IBAction func searchPressed(_: UIButton) {
        searchTextField.endEditing(true)
    }

    func textFieldShouldReturn(_: UITextField) -> Bool {
        searchTextField.endEditing(true)
        return true
    }

    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        if textField.text != "" {
            return true
        } else {
            textField.placeholder = "Type something"
            return false
        }
    }

    func textFieldDidEndEditing(_: UITextField) {
        if let city = searchTextField.text {
            weatherManager.fetchWeather(cityName: city)
        }

        searchTextField.text = ""
    }
}

// MARK: - WeatherManagerDelegate

extension WeatherViewController: WeatherManagerDelegate {
    func didUpdateWeather(_: WeatherManager, weather: WeatherModel) {
        DispatchQueue.main.async {
            self.temperatureLabel.text = weather.temperatureString
            self.conditionImageView.image = UIImage(systemName: weather.conditionName)
            self.cityLabel.text = weather.cityName
        }
    }

    func didFailWithError(error: Error) {
        print(error)
    }
}

// MARK: - CLLocationManagerDelegate

// extension WeatherViewController: CLLocationManagerDelegate {
//
//    @IBAction func locationPressed(_ sender: UIButton) {
//        locationManager.requestLocation()
//    }
//
//    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
//        if let location = locations.last {
//            locationManager.stopUpdatingLocation()
//            let lat = location.coordinate.latitude
//            let lon = location.coordinate.longitude
//            weatherManager.fetchWeather(latitude: lat, longitude: lon)
//        }
//    }
//
//    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
//        print(error)
//    }
// }

//
//  WeatherViewController.swift
//  Clima
//
//  Created by Angela Yu on 01/09/2019.
//  Copyright © 2019 App Brewery. All rights reserved.
//

import CoreLocation
import UIKit

class WeatherViewController: UIViewController {
    @IBOutlet var conditionImageView: UIImageView!
    @IBOutlet var temperatureLabel: UILabel!
    @IBOutlet var cityLabel: UILabel!
    @IBOutlet var searchTextField: UITextField!

    var weatherManager = WeatherManager()
    let locationManager = CLLocationManager()
    let fetchOptions = 3

    override func viewDidLoad() {
        super.viewDidLoad()

        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.requestLocation()

        weatherManager.delegate = self
        searchTextField.delegate = self

        locationManager.requestLocation()
    }
}

// MARK: - UITextFieldDelegate

extension WeatherViewController: UITextFieldDelegate {
    @IBAction func searchPressed(_: UIButton) {
        searchTextField.endEditing(true)
    }

    func textFieldShouldReturn(_: UITextField) -> Bool {
        searchTextField.endEditing(true)
        return true
    }

    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        if textField.text != "" {
            return true
        } else {
            textField.placeholder = "Type something"
            return false
        }
    }

    func textFieldDidEndEditing(_: UITextField) {
        if let city = searchTextField.text {
            weatherManager.fetchWeather(cityName: city, option: fetchOptions)
        }

        searchTextField.text = ""
    }
}

// MARK: - WeatherManagerDelegate

extension WeatherViewController: WeatherManagerDelegate {
    func didUpdateWeather(_: WeatherManager, option: Int, urlString: String?) {
        let url = urlString ?? weatherManager.weatherURL
        switch option {
        case 1:
            initWeatherManager1(urlString: url)
        case 2:
            initWeatherManager2(urlString: url)
        case 3:
            initWeatherManager3(urlString: url)
        default:
            break
        }
    }

    func didFailWithError(_ error: any Error) {
        print(error.localizedDescription)

        let alert = UIAlertController(
            title: "Error",
            message: "Failed to fetch weather data. Please try again later.",
            preferredStyle: .alert
        )
        alert.addAction(
            UIAlertAction(
                title: "OK", style: .default, handler: nil
            ))
        present(alert, animated: true, completion: nil)
    }

    // Không có async/await
    func initWeatherManager1(urlString: String) {
        weatherManager.fetchAPI1(with: urlString) { (result: Result<WeatherData, Error>) in
            DispatchQueue.main.async {
                switch result {
                case let .success(weatherData):
                    if let weatherModel = self.weatherManager.parseJSON(weatherData) {
                        self.temperatureLabel.text = weatherModel.formattedTemp
                        self.cityLabel.text = weatherModel.cityName
                        self.conditionImageView.image = UIImage(systemName: weatherModel.conditionImage)
                    }
                case let .failure(error):
                    self.didFailWithError(error)
                }
            }
        }
    }

    // Cách 1: Async/Await
    func initWeatherManager2(urlString: String) {
        Task.init {
            do {
                let result: WeatherData = try await weatherManager.fetchAPI2(with: urlString)
                if let weatherModel = self.weatherManager.parseJSON(result) {
                    self.temperatureLabel.text = weatherModel.formattedTemp
                    self.cityLabel.text = weatherModel.cityName
                    self.conditionImageView.image = UIImage(systemName: weatherModel.conditionImage)
                }
            } catch {
                didFailWithError(error)
            }
        }
    }

    // Cách 2: Async with Completion Handler
    func initWeatherManager3(urlString: String) {
        Task.init {
            do {
                let result = try await weatherManager.loadAPI3(with: urlString)
                if let weatherModel = self.weatherManager.parseJSON(result) {
                    self.temperatureLabel.text = weatherModel.formattedTemp
                    self.cityLabel.text = weatherModel.cityName
                    self.conditionImageView.image = UIImage(systemName: weatherModel.conditionImage)
                }
            } catch {
                didFailWithError(error)
            }
        }
    }
}

// MARK: - CLLocationManagerDelegate

extension WeatherViewController: CLLocationManagerDelegate {
    @IBAction func locationPressed(_: UIButton) {
        locationManager.requestLocation()
    }

    func locationManager(
        _: CLLocationManager, didUpdateLocations locations: [CLLocation]
    ) {
        if let location = locations.last {
            locationManager.stopUpdatingLocation()
            let lat = location.coordinate.latitude
            let lon = location.coordinate.longitude
            weatherManager.fetchWeather(latitude: lat, longitude: lon, option: fetchOptions)
        }
    }

    func locationManager(
        _: CLLocationManager, didFailWithError error: Error
    ) {
        print(error)
    }
}

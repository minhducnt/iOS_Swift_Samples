//
//  APIError.swift
//  Clima
//
//  Created by TMA on 14/2/25.
//  Copyright © 2025 App Brewery. All rights reserved.
//

enum APIError: Error {
    case error(String)

    var localizedDescription: String {
        switch self {
        case let .error(string):
            return string
        }
    }
}

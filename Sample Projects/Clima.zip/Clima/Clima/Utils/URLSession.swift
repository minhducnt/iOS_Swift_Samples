//
//  URLSession.swift
//  Clima
//
//  Created by TMA on 14/2/25.
//  Copyright © 2025 App Brewery. All rights reserved.
//
import UIKit

extension URLSession {
    func data(url: URL) async throws -> Data {
        try await withCheckedThrowingContinuation { c in
            dataTask(with: url) { data, _, error in
                if let error = error {
                    c.resume(throwing: APIError.error(error.localizedDescription))
                } else {
                    if let data = data {
                        c.resume(returning: data)
                    } else {
                        c.resume(throwing: APIError.error("Bad response"))
                    }
                }
            }.resume()
        }
    }
}

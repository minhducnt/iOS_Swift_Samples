//
//  WeatherManager.swift
//  Clima
//
//  Created by TMA on 14/2/25.
//  Copyright © 2025 App Brewery. All rights reserved.
//

import CoreLocation
import Foundation

protocol WeatherManagerDelegate {
    func didUpdateWeather(_ weatherManager: WeatherManager, option: Int, urlString: String?)
    func didFailWithError(_ error: Error)
}

struct WeatherManager {
    var delegate: WeatherManagerDelegate?

    let weatherURL = "https://api.openweathermap.org/data/2.5/weather?APPID=99ff5967b746af066812fa3ac3251ebc&units=metric"

    func fetchWeather(cityName: String, option: Int) {
        let urlString = "\(weatherURL)&q=\(cityName)"
        delegate?.didUpdateWeather(self, option: option, urlString: urlString)
    }

    func fetchWeather(latitude: CLLocationDegrees, longitude: CLLocationDegrees, option: Int) {
        let urlString = "\(weatherURL)&lat=\(latitude)&lon=\(longitude)"
        delegate?.didUpdateWeather(self, option: option, urlString: urlString)
    }

    // MARK: - Perform Request

    // Cách 1
    func fetchAPI1<T: Codable>(with weatherURL: String, completion: @escaping (Result<T, Error>) -> Void) {
        URLSession.shared.dataTask(with: URL(string: weatherURL)!) { data, response, error in
            if let error = error {
                completion(.failure(error))
                return
            }

            guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200, let data = data else {
                completion(.failure(APIError.error("Bad HTTP Response")))
                return
            }

            do {
                let decodedData = try JSONDecoder().decode(T.self, from: data)
                completion(.success(decodedData))
            } catch {
                completion(.failure(error))
            }
        }
        .resume()
    }

    // Cách 2: Async/Await
    func fetchAPI2<T: Codable>(with weatherURL: String) async throws -> T {
        let data = try await URLSession.shared.data(url: URL(string: weatherURL)!)
        let decodeData = try JSONDecoder().decode(T.self, from: data)
        return decodeData
    }

    // Cách 3: Async with Completion Handler
    func loadAPI3(with weatherURL: String) async throws -> WeatherData {
        try await withCheckedThrowingContinuation { c in

            fetchAPI1(with: weatherURL) { (result: Result<WeatherData, Error>) in
                switch result {
                case let .success(result):
                    c.resume(returning: result)
                case let .failure(error):
                    c.resume(throwing: error)
                }
            }
        }
    }

    // Cách 4: Fetch group APIs
    func fetchAPI<T: Codable>(url _: URL) async throws -> T {
        let data = try await URLSession.shared.data(url: URL(string: weatherURL)!)
        let decodeData = try JSONDecoder().decode(T.self, from: data)
        return decodeData
    }

    // MARK: - Parse Data

    func parseJSON(_ weatherData: WeatherData) -> WeatherModel? {
        let id = weatherData.weather?[0].id ?? 0
        let temp = weatherData.main?.temp ?? 0.0
        let name = weatherData.name ?? "Unknown"

        let weather = WeatherModel(conditionId: id, cityName: name, temperature: temp)
        return weather
    }
}

//
//  ViewController.swift
//  Quizzler-iOS13
//
//  Created by Angela Yu on 12/07/2019.
//  Copyright © 2019 The App Brewery. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet var questionLabel: UILabel!
    @IBOutlet var progressBar: UIProgressView!
    @IBOutlet var trueButton: UIButton!
    @IBOutlet var falseButton: UIButton!

    let quizzets = [
        Question(text: "What is 2 + 2", answer: "True"),
        Question(text: "What is 2 + 3", answer: "False"),
        Question(text: "What is 2 + 4", answer: "True"),
        Question(text: "What is 2 + 5", answer: "False"),
    ]
    var quizNumber = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        questionLabel.text = quizzets[quizNumber].text
        progressBar.setProgress(0, animated: true)
    }

    @IBAction func answerButtonPressed(_ sender: UIButton) {
        if quizNumber == quizzets.count - 1 {
            quizNumber = 0
        }
        quizNumber += 1

        let userAnswer: String = sender.currentTitle!
        let actualAnswer = quizzets[quizNumber].answer

        if userAnswer == actualAnswer {
            sender.backgroundColor = UIColor.green
            trueButton.titleLabel?.textColor = .white
        } else {
            sender.backgroundColor = UIColor.red
            falseButton.titleLabel?.textColor = .white
        }
    }

    func updateUI() {
        trueButton.backgroundColor = .clear
        falseButton.backgroundColor = .clear
        questionLabel.text = quizzets[quizNumber].text
        progressBar.progress = Float(quizNumber) / Float(quizzets.count)
    }

    struct Question {
        let text: String
        let answer: String

        init(text: String, answer: String) {
            self.text = text
            self.answer = answer
        }
    }
}
